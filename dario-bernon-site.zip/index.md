---
layout: default
title: Home
---

# Dario Bernoni

## Tra ingegneria e calcio

Benvenuto nel mio spazio personale dedicato ad allenamento, metodologia e formazione calcistica.

## Ultimi articoli

{% for post in site.posts limit:10 %}
- [{{ post.title }}]({{ post.url }})
{% endfor %}
